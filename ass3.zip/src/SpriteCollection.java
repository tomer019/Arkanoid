//319126991 Tomer Grady

import biuoop.DrawSurface;
import java.util.LinkedList;
import java.util.List;

/**
 * The SpriteCollection class manages a collection of Sprite objects in the game.
 * It provides methods to add sprites, notify them that time has passed, and draw them on a given surface.
 */
public class SpriteCollection {
    private final List<Sprite> spritesOfGame = new LinkedList<>();

    /**
     * Adds a sprite to the collection.
     *
     * @param s the sprite to add
     */
    public void addSprite(Sprite s) {
        spritesOfGame.add(s);
    }

    /**
     * Calls the timePassed() method on all sprites in the collection.
     */
    public void notifyAllTimePassed() {
        for (Sprite sprite : spritesOfGame) {
            sprite.timePassed();
        }
    }

    /**
     * Calls the drawOn(d) method on all sprites in the collection.
     *
     * @param d the drawing surface
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite sprite : spritesOfGame) {
            sprite.drawOn(d);
        }
    }
}
