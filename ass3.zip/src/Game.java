// 319126991 Tomer Grady

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import biuoop.Sleeper;

import java.awt.Color;
import java.util.Random;

/**
 * The Game class manages the game environment, sprites, and the game loop.
 * It initializes the game, creates game objects, and runs the animation loop.
 */
public class Game {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Random rand = new Random();

    private static final int SCREEN_WIDTH = 800;
    private static final int SCREEN_HEIGHT = 600;
    private static final int BLOCK_WIDTH = 50;
    private static final int BLOCK_HEIGHT = 25;

    /**
     * Constructs a new Game with an empty sprite collection and game environment.
     * Initializes the GUI for the game.
     */
    public Game() {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.gui = new GUI("Game", SCREEN_WIDTH, SCREEN_HEIGHT);
    }

    /**
     * Adds a collidable object to the game environment.
     *
     * @param c the collidable object to add
     */
    public void addCollidable(Collidable c) {
        environment.addCollidable(c);
    }

    /**
     * Adds a sprite to the sprite collection.
     *
     * @param s the sprite to add
     */
    public void addSprite(Sprite s) {
        sprites.addSprite(s);
    }

    /**
     * Initializes the game by creating blocks, paddle, and balls.
     * Adds dividers between blocks for better visual separation.
     */
    public void initialize() {
        KeyboardSensor keyboard = gui.getKeyboardSensor();

        // Create black dividers and colored blocks
        for (int i = 0; i < 6; i++) {
            Color color = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256)); // Random color
            for (int j = 0; j < 12 - i; j++) {
                int x = SCREEN_WIDTH - 50 - (j * (BLOCK_WIDTH + 2));
                int y = 100 + (i * (BLOCK_HEIGHT + 2));

                // Create black dividers
                Block dividerHorizontal = new Block(new Rectangle(new Point(x, y - 2), BLOCK_WIDTH, 2), Color.BLACK);
                dividerHorizontal.addToGame(this);
                Block dividerVertical = new Block(new Rectangle(new Point(x - 2, y), 2, BLOCK_HEIGHT), Color.BLACK);
                dividerVertical.addToGame(this);
                Block dividerBottom = new Block(new Rectangle(
                        new Point(x, y + BLOCK_HEIGHT), BLOCK_WIDTH, 2), Color.BLACK);
                dividerBottom.addToGame(this);

                // Create colored blocks
                Block block = new Block(new Rectangle(new Point(x, y), BLOCK_WIDTH, BLOCK_HEIGHT), color);
                block.addToGame(this);
            }
        }

        // Initialize the paddle
        Paddle paddle = new Paddle(keyboard, new Rectangle(new Point(400, 575), 150, 10), Color.green, 10);
        paddle.addToGame(this);

        // Initialize the balls
        int size = 10;
        Ball[] balls = {
                new Ball(new Point(500, 400), size, Color.black),
                new Ball(new Point(400, 400), size, Color.black),
        };

        for (Ball ball : balls) {
            ball.setGameEnvironment(environment);
            ball.setVelocity(Velocity.fromAngleAndSpeed(180, 7));
            ball.addToGame(this);
        }

        // Adding boundary blocks
        Block top = new Block(new Rectangle(new Point(0, 0), SCREEN_WIDTH, 10), Color.BLACK);
        Block bottom = new Block(new Rectangle(new Point(0, SCREEN_HEIGHT - 10), SCREEN_WIDTH, 10), Color.BLACK);
        Block left = new Block(new Rectangle(new Point(0, 10), 10, SCREEN_HEIGHT - 20), Color.BLACK);
        Block right = new Block(new Rectangle(new Point(SCREEN_WIDTH - 10, 10), 10, SCREEN_HEIGHT - 20), Color.BLACK);
        top.addToGame(this);
        bottom.addToGame(this);
        left.addToGame(this);
        right.addToGame(this);
    }

    /**
     * Runs the game animation loop, updating and drawing sprites.
     */
    public void run() {
        Sleeper sleeper = new Sleeper();
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis();
            DrawSurface d = gui.getDrawSurface();

            // Set background color to blue
            d.setColor(Color.DARK_GRAY);
            d.fillRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

    /**
     * The main method to start and run the game.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
