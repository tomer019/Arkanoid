// 319126991 Tomer Grady

import biuoop.DrawSurface;

import java.awt.Color;

/**
 * The Ball class represents a ball in a 2D space that can move and bounce off boundaries.
 */
public class Ball implements Sprite {
    // The fields
    private Point center;
    private double radius;
    private Color color;
    private Velocity velocity;
    private static final double THRESHOLD = 0.000001; // Define a small threshold for floating-point comparison
    private GameEnvironment gameEnvironment;

    /**
     * Constructs a Ball with the specified center point, radius, and color.
     *
     * @param center the center point of the ball
     * @param radius the radius of the ball
     * @param color  the color of the ball
     */
    public Ball(Point center, double radius, java.awt.Color color) {
        this.center = center;
        this.radius = radius;
        this.color = color;
    }

    /**
     * Gets the center point of the ball.
     *
     * @return the center point
     */
    public Point getCenter() {
        return center;
    }

    /**
     * Gets the color of the ball.
     *
     * @return the color
     */
    public Color getColor() {
        return color;
    }

    /**
     * Sets the velocity of the ball.
     *
     * @param v the new velocity
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }

    /**
     * Gets the velocity of the ball.
     *
     * @return the velocity
     */
    public Velocity getVelocity() {
        return velocity;
    }

    /**
     * Gets the size of the ball.
     *
     * @return the radius of the ball
     */
    public double getSize() {
        return radius;
    }

    /**
     * Draws the ball on the given drawing surface.
     *
     * @param surface the drawing surface
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(color);
        surface.fillCircle((int) center.getX(), (int) center.getY(), (int) radius);
    }

    /**
     * Sets the game environment for the ball.
     *
     * @param gameEnvironment the game environment
     */
    public void setGameEnvironment(GameEnvironment gameEnvironment) {
        this.gameEnvironment = gameEnvironment;
    }

    /**
     * Moves the ball one step, updating its position based on its velocity,
     * and handles collisions with collidable objects in the game environment.
     */
    public void moveOneStep() {
        // Compute the trajectory of the ball
        Line trajectory = new Line(center, velocity.applyToPoint(center));
        double newLength = radius + trajectory.length();
        double x = ((trajectory.end().getX() * newLength) - radius * trajectory.start().getX()) / trajectory.length();
        double y = ((trajectory.end().getY() * newLength) - radius * trajectory.start().getY()) / trajectory.length();

        Line extendedLine = new Line(trajectory.start(), new Point(x, y));
        CollisionInfo collisionInfo = gameEnvironment.getClosestCollision(extendedLine);

        if (collisionInfo == null) {
            // No collision, move the ball to the end of the trajectory
            this.center = trajectory.end();
        } else {
            // Collision detected, update velocity and handle collision
            this.velocity = collisionInfo.collisionObject().hit(collisionInfo.collisionPoint(), velocity);
        }
    }

    /**
     * Adds the ball to the game, registering it as a sprite.
     *
     * @param g the game to add the ball to
     */
    public void addToGame(Game g) {
        g.addSprite(this);
    }

    /**
     * Notifies the ball that time has passed, moving it one step.
     */
    public void timePassed() {
        moveOneStep();
    }
}
