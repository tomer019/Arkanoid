// 319126991 Tomer Grady

import biuoop.DrawSurface;
import java.awt.Color;

/**
 * The Block class represents a block in a 2D space that can be collided with and drawn on the screen.
 * It implements the Collidable and Sprite interfaces.
 */
public class Block implements Collidable, Sprite {
    private final Rectangle rectangle;
    private final Color color;
    private static final double THRESHOLD = 0.000001; // Define a small threshold for floating-point comparison

    /**
     * Constructs a Block with the specified rectangle and color.
     *
     * @param rectangle the collision rectangle of the block
     * @param color     the color of the block
     */
    public Block(Rectangle rectangle, Color color) {
        this.rectangle = rectangle;
        this.color = color;
    }

    /**
     * Returns the collision rectangle of the block.
     *
     * @return the collision rectangle
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return rectangle;
    }

    /**
     * Updates the velocity of the ball upon hitting the block.
     *
     * @param collisionPoint   the point at which the collision occurred
     * @param currentVelocity the current velocity of the ball
     * @return the new velocity after the hit
     */
    @Override
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        double upperY = rectangle.getUpperLeft().getY();
        double lowerY = upperY + rectangle.getHeight();
        double leftX = rectangle.getUpperLeft().getX();
        double rightX = leftX + rectangle.getWidth();

        boolean top = Math.abs(collisionPoint.getY() - upperY) < THRESHOLD;
        boolean bottom = Math.abs(collisionPoint.getY() - lowerY) < THRESHOLD;
        boolean left = Math.abs(collisionPoint.getX() - leftX) < THRESHOLD;
        boolean right = Math.abs(collisionPoint.getX() - rightX) < THRESHOLD;

        if (top || bottom) {
            return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
        }
        if (left || right) {
            return new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
        }
        return currentVelocity;
    }

    /**
     * Draws the block on the given drawing surface.
     *
     * @param d the drawing surface
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) rectangle.getUpperLeft().getX(), (int) rectangle.getUpperLeft().getY(),
                (int) rectangle.getWidth(), (int) rectangle.getHeight());
    }

    /**
     * Adds the block to the game, registering it as both a collidable and a sprite.
     *
     * @param g the game to add the block to
     */
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * Notifies the block that time has passed. Currently, the block does not change over time.
     */
    @Override
    public void timePassed() {
        // No action needed for this implementation
    }
}
