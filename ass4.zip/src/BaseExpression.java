//Tomer Grady 319126991
import java.util.HashMap;

/**
 * BaseExpression is an abstract class that provides a default implementation for the evaluate method
 * without parameters by calling the evaluate method with an empty assignment.
 */
public abstract class BaseExpression implements Expression {
    /**
     * Evaluates the expression using an empty variable assignment.
     *
     * @return the boolean result of the expression evaluation
     * @throws Exception if there is an issue with the evaluation
     */
    @Override
    public Boolean evaluate() throws Exception {
        return evaluate(new HashMap<>());
    }
}
