//Tomer Grady 319126991
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Var class represents a variable in a boolean expression.
 */
public class Var implements Expression {
    private final String varName;

    /**
     * Constructor.
     *
     * @param name the variable's name.
     */
    public Var(String name) {
        this.varName = name;
    }

    /**
     * Evaluates the variable based on the given variable assignments.
     *
     * @param task the variable assignments.
     * @return the boolean value of the variable.
     * @throws Exception if the variable is not set in the assignment.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> task) throws Exception {
        if (task.containsKey(varName)) {
            return task.get(varName);
        }
        throw new Exception(String.format("'%s' variable was not set in assignment.", varName));
    }

    /**
     * Evaluates the variable without any variable assignments.
     *
     * @return the boolean value of the variable.
     * @throws Exception since the variable is not set in the assignment.
     */
    @Override
    public Boolean evaluate() throws Exception {
        return evaluate(new HashMap<>());
    }

    /**
     * Returns a list containing the variable's name.
     *
     * @return a list containing the variable's name.
     */
    @Override
    public List<String> getVariables() {
        List<String> list = new ArrayList<>();
        list.add(varName);
        return list;
    }

    /**
     * Returns a new expression in which all occurrences of the variable var are replaced with the provided expression.
     *
     * @param var        the variable to be replaced.
     * @param expression the expression to replace the variable.
     * @return the new expression.
     */
    @Override
    public Expression assign(String var, Expression expression) {
        if (var.equals(varName)) {
            return expression;
        }
        return this;
    }

    /**
     * Returns this variable since it cannot be converted to NAND form.
     *
     * @return this variable.
     */
    @Override
    public Expression nandify() {
        return this;
    }

    /**
     * Returns this variable since it cannot be converted to NOR form.
     *
     * @return this variable.
     */
    @Override
    public Expression norify() {
        return this;
    }

    /**
     * Returns this variable since it is already simplified.
     *
     * @return this variable.
     */
    @Override
    public Expression simplify() {
        return this;
    }

    /**
     * Returns the string representation of the variable's name.
     *
     * @return the variable's name.
     */
    @Override
    public String toString() {
        return varName;
    }

    /**
     * Checks if this variable is equal to another object.
     *
     * @param object the other object.
     * @return true if the variable names are equal, false otherwise.
     */
    @Override
    public boolean equals(Object object) {
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        Var other = (Var) object;
        return varName.equals(other.varName);
    }


    /**
     * Returns the hash code of the variable's name.
     *
     * @return the hash code of the variable's name.
     */
    @Override
    public int hashCode() {
        return varName.hashCode();
    }
}
