//Tomer Grady 319126991
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Val class represents a boolean value in a boolean expression.
 */
public class Val implements Expression {
    private final boolean expressionValue;
    public static final Val FALSE = new Val(false);
    public static final Val TRUE = new Val(true);
    /**
     * Constructor.
     *
     * @param value the boolean value.
     */
    public Val(boolean value) {
        this.expressionValue = value;
    }

    /**
     * Evaluates the expression based on the given variable assignments.
     *
     * @param task the variable assignments.
     * @return the boolean value of the expression.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> task) throws Exception {
        return expressionValue;
    }

    /**
     * Evaluates the expression without any variable assignments.
     *
     * @return the boolean value of the expression.
     */
    @Override
    public Boolean evaluate() throws Exception {
        return evaluate(new HashMap<>());
    }

    /**
     * Returns an empty list since this expression contains no variables.
     *
     * @return an empty list.
     */
    @Override
    public List<String> getVariables() {
        return new ArrayList<>();
    }

    /**
     * Returns this expression since it cannot be assigned any variables.
     *
     * @param var the variable to be replaced.
     * @param expression the expression to replace the variable.
     * @return this expression.
     */
    @Override
    public Expression assign(String var, Expression expression) {
        return this;
    }

    /**
     * Returns this expression since it cannot be converted to NAND form.
     *
     * @return this expression.
     */
    @Override
    public Expression nandify() {
        return this;
    }

    /**
     * Returns this expression since it cannot be converted to NOR form.
     *
     * @return this expression.
     */
    @Override
    public Expression norify() {
        return this;
    }

    /**
     * Returns this expression since it is already simplified.
     *
     * @return this expression.
     */
    @Override
    public Expression simplify() {
        return this;
    }

    /**
     * Returns a string representation of the boolean value.
     *
     * @return "T" for true, "F" for false.
     */
    @Override
    public String toString() {
        return expressionValue ? "T" : "F";
    }

    /**
     * Checks if this expression is equal to another object.
     *
     * @param object the other object.
     * @return true if the values are equal, false otherwise.
     */
    @Override
    public boolean equals(Object object) {
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        Val other = (Val) object;
        return this.expressionValue == other.expressionValue;
    }


    /**
     * Returns the hash code of the boolean value.
     *
     * @return 1 if the value is true, 0 if false.
     */
    @Override
    public int hashCode() {
        return (expressionValue ? 1 : 0);
    }
}
