//Tomer Grady 319126991

/**
 * The Xnor class represents the logical XNOR (exclusive NOR) operation.
 */
public class Xnor extends BinaryExpression {
    /**
     * Constructor.
     *
     * @param first  an operand.
     * @param second an operand.
     */
    public Xnor(Expression first, Expression second) {
        super(first, second);
    }

    /**
     * Calculates the result of the XNOR operation.
     *
     * @param one the first operand.
     * @param two the second operand.
     * @return the result of the XNOR operation.
     */
    @Override
    public boolean calculate(boolean one, boolean two) {
        return one == two;
    }

    /**
     * Converts the XNOR expression to its NAND equivalent.
     *
     * @return the NAND equivalent of the XNOR expression.
     */
    @Override
    public Expression nandify() {

        // Nandify the first and second operand of the Xnor expression
        Expression firstNandified = getRight().nandify();
        Expression secondNandified = getLeft().nandify();

        // Create a NAND of the first and second operand with itself (equivalent to NOT)
        Expression firstNot = new Nand(firstNandified, firstNandified);
        Expression secondNot = new Nand(secondNandified, secondNandified);

        // Create a NAND of the first and second operands
        Expression firstSecondNand = new Nand(firstNandified, secondNandified);

        // Return the NAND equivalent of the Xnor operation using NAND expressions
        return new Nand(new Nand(firstNot, secondNot), firstSecondNand);
    }


    /**
     * Converts the XNOR expression to its NOR equivalent.
     *
     * @return the NOR equivalent of the XNOR expression.
     */
    @Override
    public Expression norify() {
        //short variable names.
        Expression leftNorRight = new Nor(getRight().norify(), getLeft().norify());
        //return 'nor' version of expression
        return new Nor(new Nor(getRight().norify(), leftNorRight), new Nor(getLeft().norify(), leftNorRight));
    }

    /**
     * Simplifies the XNOR expression.
     *
     * @return the simplified expression.
     */
    @Override
    public Expression simplify() {
        Expression result = super.simplify();

        if (result.equals(Val.TRUE) || result.equals(Val.FALSE)) {
            return result;
        }

        Expression first = getRight().simplify();
        Expression second = getLeft().simplify();

        if (first.equals(second)) {
            return Val.TRUE;
        }
        return new Xnor(first, second);
    }

    /**
     * Returns a string representation of the XNOR expression.
     *
     * @return a string representation of the XNOR expression.
     */
    @Override
    public String toString() {
        return "(" + getRight() + " # " + getLeft() + ")";
    }
}
