import java.util.HashMap;

/**
 * Class with main to test the Expression classes.
 */
public class ExpressionsTest {

    /**
     * Main method which runs code.
     *
     * @param args relevant arguments
     */
    public static void main(String[] args) throws Exception {
        // 1. Create an expression with at least three variables.
        Expression x = new Var("x");
        Expression y = new Var("y");
        Expression z = new Var("z");
        Expression ex = new And(new Or(x, y), new Not(z));

        // 2. Print the expression.
        System.out.println(ex);

        // 3. Print the value of the expression with an assignment to every variable.
        HashMap<String, Boolean> map = new HashMap<>();
        map.put("x", true);
        map.put("y", false);
        map.put("z", false);
        try {
            System.out.println(ex.evaluate(map));
        } catch (Exception e) {
            System.out.println("Evaluation failed: " + e.getMessage());
        }

        // 4. Print the Nandified version of the expression.
        System.out.println(ex.nandify());

        // 5. Print the Norified version of the expression.
        System.out.println(ex.norify());

        // 6. Print the simplified version of the expression.
        System.out.println(ex.simplify());
    }
}
