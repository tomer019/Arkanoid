//Tomer Grady 319126991

/**
 * The Nor class represents a binary NOR (Not OR) expression.
 */
public class Nor extends BinaryExpression {
    /**
     * Constructor.
     *
     * @param first  the first operand.
     * @param second the second operand.
     */
    public Nor(Expression first, Expression second) {
        super(first, second);
    }

    /**
     * Applies the NOR operation on the operands.
     *
     * @param one the first operand.
     * @param two the second operand.
     * @return the result of the NOR operation.
     */
    @Override
    public boolean calculate(boolean one, boolean two) {
        return !(one || two);
    }

    /**
     * Returns a new expression where all operations are expressed using only NAND operations.
     *
     * @return the NANDified expression.
     */
    @Override
    public Expression nandify() {

        //assigning short variable names.
        Expression first = new Nand(getRight().nandify(), getLeft().nandify());
        Expression second = new Nand(getLeft().nandify(), getRight().nandify());

        // return 'nand' form of expression.
        return new Nand(new Nand(first, second), new Nand(first, second));
    }

    /**
     * Returns a new expression where all operations are expressed using only NOR operations.
     *
     * @return the NORified expression.
     */
    @Override
    public Expression norify() {
        return new Nor(getRight().norify(), getLeft().norify());
    }

    /**
     * Simplifies the expression as much as possible.
     *
     * @return the simplified expression.
     */

    /**
     * Returns a string representation of the expression.
     *
     * @return the string representation.
     */
    @Override
    public String toString() {
        return "(" + getRight() + " V " + getLeft() + ")";
    }

    @Override
    public Expression simplify() {
        Expression result = super.simplify();

        if (result.equals(Val.TRUE) || result.equals(Val.FALSE)) {
            return result;
        }

        Expression first = getRight().simplify();
        Expression second = getLeft().simplify();

        // Applying simplification rules specific to NOR
        if ((first.equals(Val.TRUE)) || (second.equals(Val.TRUE))) {
            return Val.FALSE; // A NOR T or T NOR A = F
        }
        if (first.equals(Val.FALSE)) {
            return new Not(second).simplify(); // F NOR A = ~A
        }
        if (second.equals(Val.FALSE)) {
            return new Not(first).simplify(); // A NOR F = ~A
        }
        if (first.equals(second)) {
            return new Not(first).simplify(); // A NOR A = ~A
        }

        return new Nor(first, second);
    }
}
