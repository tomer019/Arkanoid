//Tomer Grady 319126991

/**
 * The Or class represents a binary OR expression.
 */
public class Or extends BinaryExpression {
    /**
     * Constructor.
     *
     * @param first  an operand.
     * @param second an operand.
     */
    public Or(Expression first, Expression second) {
        super(first, second);
    }

    /**
     * Applies the OR operation on the operands.
     *
     * @param one the first operand.
     * @param two the second operand.
     * @return the result of the OR operation.
     */
    @Override
    public boolean calculate(boolean one, boolean two) {
        return one || two;
    }

    /**
     * Returns a new expression where all operations are expressed using only NAND operations.
     *
     * @return the NANDified expression.
     */
    @Override
    public Expression nandify() {
        Expression first = getRight().nandify();
        Expression second = getLeft().nandify();
        // OR can be expressed as (A NAND A) NAND (B NAND B)
        return new Nand(new Nand(first, first), new Nand(second, second));
    }

    /**
     * Returns a new expression where all operations are expressed using only NOR operations.
     *
     * @return the NORified expression.
     */
    @Override
    public Expression norify() {
        Expression expression = new Nor(super.getRight().norify(), super.getLeft().norify());
        return new Nor(expression, expression);
    }

    /**
     * Simplifies the expression as much as possible.
     *
     * @return the simplified expression.
     */
    @Override
    public Expression simplify() {
        Expression result = super.simplify();

        // Return the simplified result if it is a constant value
        if (result.equals(Val.TRUE) || result.equals(Val.FALSE)) {
            return result;
        }

        Expression first = getRight().simplify();
        Expression second = getLeft().simplify();

        // Simplify according to the OR operation rules
        if (first.equals(Val.FALSE)) {
            return second;
        }
        if (second.equals(Val.FALSE)) {
            return first;
        }
        if ((first.equals(Val.TRUE)) || (second.equals(Val.TRUE))) {
            return Val.TRUE;
        }
        if (first.equals(second)) {
            return first;
        }
        return new Or(first, second);
    }

    /**
     * Returns a string representation of the expression.
     *
     * @return the string representation.
     */
    @Override
    public String toString() {
        return "(" + getRight() + " | " + getLeft() + ")";
    }
}
