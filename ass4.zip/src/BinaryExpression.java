//Tomer Grady 319126991

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The BinaryExpression class is an abstract base class for binary expressions, which are expressions
 * that have two operands and a binary operator.
 */
public abstract class BinaryExpression extends BaseExpression {
    private final Expression right;
    private final Expression left;

    /**
     * Constructor.
     *
     * @param right  an operand.
     * @param left an operand.
     */
    public BinaryExpression(Expression right, Expression left) {
        this.right = right;
        this.left = left;
    }

    /**
     * Applying the operator on the operands.
     *
     * @param one operand.
     * @param two operand.
     * @return the applied value.
     */
    public abstract boolean calculate(boolean one, boolean two);

    /**
     * @return the first operand.
     */
    public Expression getRight() {
        return right;
    }

    /**
     * @return the second operand.
     */
    public Expression getLeft() {
        return left;
    }

    /**
     * Returns a list of variables in the expression.
     *
     * @return a list of variable names.
     */
    @Override
    public List<String> getVariables() {
        Set<String> variables = new HashSet<>();

        // Add variables from both operands
        variables.addAll(right.getVariables());
        variables.addAll(left.getVariables());

        return new ArrayList<>(variables);
    }

    /**
     * Assigns the given expression to the specified variable in both operands.
     *
     * @param var        the variable to be replaced.
     * @param expression the expression to replace the variable with.
     * @return a new expression with the variable replaced by the given expression.
     */
    @Override
    public Expression assign(String var, Expression expression) {
        try {
            // Use reflection to create a new instance of the current class with assigned operands
            return this.getClass().getConstructor(Expression.class, Expression.class)
                    .newInstance(right.assign(var, expression), left.assign(var, expression));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Evaluates the expression based on the given variable assignments.
     *
     * @param assignment a map of variable assignments.
     * @return the result of the evaluation.
     * @throws Exception if there is an issue with the evaluation.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return calculate(right.evaluate(assignment), left.evaluate(assignment));
    }

    /**
     * Simplifies the expression.
     *
     * @return the simplified expression.
     */
    @Override
    public Expression simplify() {
        // If the expression can be evaluated, return a Val with the result
        try {
            return new Val(evaluate());
        } catch (Exception e) {
            // If evaluation fails, return the current expression
            return this;
        }
    }

    /**
     * Checks if the given object is equal to this expression.
     *
     * @param obj the object to compare to.
     * @return true if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (!this.getClass().isInstance(obj)) {
            return false;
        }
        // Check equality of operands, considering commutativity
        return (right.equals(((BinaryExpression) obj).right) && left.equals(((BinaryExpression) obj).left))
                || (left.equals(((BinaryExpression) obj).right)
                && right.equals(((BinaryExpression) obj).left));
    }

    /**
     * Returns the hash code of the expression.
     *
     * @return the hash code.
     */
    @Override
    public int hashCode() {
        return 17 * getRight().hashCode() + 37 * getLeft().hashCode();
    }
}
