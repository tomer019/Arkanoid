//Tomer Grady 319126991
/**
 * The Not class represents a unary NOT (negation) expression.
 */
public class Not extends UnaryExpression {
    /**
     * Constructor.
     *
     * @param expression an operand.
     */
    public Not(Expression expression) {
        super(expression);
    }

    /**
     * Applies the NOT operation on the operand.
     *
     * @param one the operand.
     * @return the negated value of the operand.
     */
    @Override
    public boolean calculate(boolean one) {
        return !one;
    }

    /**
     * Returns a new expression where all operations are expressed using only NAND operations.
     *
     * @return the NANDified expression.
     */
    @Override
    public Expression nandify() {
        Expression expression = getExpression().nandify();
        // NOT A can be expressed as A NAND A
        return new Nand(expression, expression);
    }

    /**
     * Returns a new expression where all operations are expressed using only NOR operations.
     *
     * @return the NORified expression.
     */
    @Override
    public Expression norify() {
        Expression expression = getExpression().norify();
        // NOT A can be expressed as A NOR A
        return new Nor(expression, expression);
    }

    /**
     * Simplifies the expression as much as possible.
     *
     * @return the simplified expression.
     */
    @Override
    public Expression simplify() {
        Expression expressionSimplified = getExpression().simplify();
        if (expressionSimplified.equals(Val.FALSE)) {
            return Val.TRUE; // NOT FALSE is TRUE
        }
        if (expressionSimplified.equals(Val.TRUE)) {
            return Val.FALSE; // NOT TRUE is FALSE
        }
        return new Not(expressionSimplified);
    }

    /**
     * Returns a string representation of the expression.
     *
     * @return the string representation.
     */
    @Override
    public String toString() {
        return "~(" + getExpression() + ")";
    }
}
