//Tomer Grady 319126991
import java.util.List;
import java.util.Map;

/**
 * The Expression interface defines the methods required for evaluating logical expressions.
 */
public interface Expression {

        /**
         * Evaluates the expression using the provided variable assignments.
         *
         * @param assignment a map containing variable assignments (variable names as keys, boolean values).
         * @return the result of the evaluation (true or false).
         * @throws Exception if the expression contains variables that are not in the assignment.
         */
        Boolean evaluate(Map<String, Boolean> assignment) throws Exception;

        /**
         * Evaluates the expression without any variable assignments.
         *
         * @return the result of the evaluation (true or false).
         * @throws Exception if the expression contains variables.
         */
        Boolean evaluate() throws Exception;

        /**
         * Retrieves a list of variables used in the expression.
         *
         * @return a list of variable names.
         */
        List<String> getVariables();

        /**
         * Returns a string representation of the expression.
         *
         * @return the string representation of the expression.
         */
        String toString();

        /**
         * Assigns a new expression to a variable in the current expression.
         *
         * @param var the variable to replace.
         * @param expression the expression to replace the variable with.
         * @return a new expression with the variable replaced.
         */
        Expression assign(String var, Expression expression);

        /**
         * Converts the expression to its NAND representation.
         *
         * @return the NAND representation of the expression.
         */
        Expression nandify();

        /**
         * Converts the expression to its NOR representation.
         *
         * @return the NOR representation of the expression.
         */
        Expression norify();

        /**
         * Simplifies the expression.
         *
         * @return the simplified expression.
         */
        Expression simplify();
}
