//Tomer Grady 319126991
import java.util.List;
import java.util.Map;

/**
 * The UnaryExpression class represents an expression with a single operand.
 */
public abstract class UnaryExpression extends BaseExpression {
    private final Expression expression;

    /**
     * Constructor.
     *
     * @param expression the operand.
     */
    public UnaryExpression(Expression expression) {
        this.expression = expression;
    }

    /**
     * Applying the operator.
     *
     * @param one a value.
     * @return the result.
     */
    public abstract boolean calculate(boolean one);

    /**
     * @return the operand.
     */
    public Expression getExpression() {
        return expression;
    }

    /**
     * Returns a list of variables in the expression.
     *
     * @return the list of variables.
     */
    @Override
    public List<String> getVariables() {
        return expression.getVariables();
    }

    /**
     * Assigns the given expression to a variable in the expression.
     *
     * @param var the variable to replace.
     * @param exp the expression to assign.
     * @return the new expression with the variable replaced.
     */
    @Override
    public Expression assign(String var, Expression exp) {
        try {
            return this.getClass().getConstructor(Expression.class).newInstance(expression.assign(var, exp));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Evaluates the expression using the given variable assignments.
     *
     * @param task the variable assignments.
     * @return the evaluated result.
     * @throws Exception if there is an error during evaluation.
     */
    @Override
    public Boolean evaluate(Map<String, Boolean> task) throws Exception {
        return calculate(expression.evaluate(task));
    }

    /**
     * Checks if this expression is equal to another object.
     *
     * @param object the other object.
     * @return true if the expressions are equal, false otherwise.
     */
    @Override
    public boolean equals(Object object) {
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        UnaryExpression other = (UnaryExpression) object;
        return expression.equals(other.expression);
    }

    /**
     * Returns the hash code of the expression.
     *
     * @return the hash code.
     */
    @Override
    public int hashCode() {
        return expression.hashCode();
    }
}
