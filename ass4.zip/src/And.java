//Tomer Grady 319126991

/**
 * The And class represents a logical AND operation between two boolean expressions.
 * It extends the BinaryExpression abstract class and implements the necessary methods
 * for evaluating, simplifying, and transforming the AND operation.
 * The class also provides methods to convert the expression to NAND and NOR formats.
 */
public class And extends BinaryExpression {

    /**
     * Constructs an And expression with two operand expressions.
     *
     * @param first  the first operand expression
     * @param second the second operand expression
     */
    public And(Expression first, Expression second) {
        super(first, second);
    }

    /**
     * Calculates the result of the AND operation on two boolean values.
     *
     * @param one the first boolean value
     * @param two the second boolean value
     * @return the result of the AND operation
     */
    @Override
    public boolean calculate(boolean one, boolean two) {
        return one && two;
    }

    /**
     * @return returns the new expression if form of 'Nand'
     */
    @Override
    public Expression nandify() {
        Expression first = new Nand(getRight().nandify(), getLeft().nandify());
        return new Nand(first, first);
    }

    /**
     * Converts the AND expression to a NOR expression.
     *
     * @return the NOR equivalent of the AND expression
     */
    @Override
    public Expression norify() {
        Expression first = getRight().norify();
        Expression second = getLeft().norify();
        return new Nor(new Nor(first, first), new Nor(second, second));
    }

    /**
     * Returns a string representation of the AND expression.
     *
     * @return the string representation of the AND expression
     */
    @Override
    public String toString() {
        return "(" + getRight() + " & " + getLeft() + ")";
    }

    /**
     * Simplifies the AND expression by evaluating constant expressions and reducing the expression tree.
     *
     * @return the simplified expression
     */
    @Override
    public Expression simplify() {
        // Simplify the first and second operand expressions
        Expression first = getRight().simplify();
        Expression second = getLeft().simplify();

        // Evaluate the simplified expressions and return appropriate results
        if (first.equals(Val.FALSE) || second.equals(Val.FALSE)) {
            return Val.FALSE;
        }
        if (first.equals(second) || second.equals(Val.TRUE)) {
            return first;
        }
        if (first.equals(Val.TRUE)) {
            return second;
        }
        return new And(first, second);
    }
}
