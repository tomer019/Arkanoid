//Tomer Grady 319126991

/**
 * The Xor class represents the logical XOR (exclusive OR) operation.
 */
public class Xor extends BinaryExpression {
    /**
     * Constructor.
     *
     * @param first  an operand.
     * @param second an operand.
     */
    public Xor(Expression first, Expression second) {
        super(first, second);
    }

    /**
     * Calculates the result of the XOR operation.
     *
     * @param one the first operand.
     * @param two the second operand.
     * @return the result of the XOR operation.
     */
    @Override
    public boolean calculate(boolean one, boolean two) {
        return one ^ two;
    }

    /**
     * Converts the XOR expression to its NAND equivalent.
     *
     * @return the NAND equivalent of the XOR expression.
     */
    @Override
    public Expression nandify() {
        // Nandify the first and second operand of the Xnor expression
        Expression first = getRight().nandify();
        Expression second = getLeft().nandify();

        // Create the NAND equivalent of the Xnor operation
        Expression firstNand = new Nand(first, new Nand(first, second));
        Expression secondNand = new Nand(second, new Nand(first, second));

        // Return the final NAND expression
        return new Nand(firstNand, secondNand);
    }


    /**
     * Converts the XOR expression to its NOR equivalent.
     *
     * @return the NOR equivalent of the XOR expression.
     */
    @Override
    public Expression norify() {
        // Norify the first and second operand of the Xor expression
        Expression first = getRight().norify();
        Expression second = getLeft().norify();

        // Create the NOR equivalent of the Xor operation
        Expression firstNor = new Nor(first, first);
        Expression secondNor = new Nor(second, second);

        // Combine the expressions to form the final NOR equivalent
        return new Nor(new Nor(firstNor, secondNor), new Nor(first, second));
    }

    /**
     * Simplifies the XOR expression.
     *
     * @return the simplified expression.
     */
    @Override
    public Expression simplify() {
        Expression result = super.simplify();

        if (result.equals(Val.TRUE) || result.equals(Val.FALSE)) {
            return result;
        }

        Expression first = getRight().simplify();
        Expression second = getLeft().simplify();

        if (first.equals(Val.TRUE)) {
            return new Not(second).simplify();
        }
        if (second.equals(Val.TRUE)) {
            return new Not(first).simplify();
        }
        if (first.equals(Val.FALSE)) {
            return second;
        }
        if (second.equals(Val.FALSE)) {
            return first;
        }
        if (first.equals(second)) {
            return Val.FALSE;
        }
        return new Xor(first, second);
    }

    /**
     * Returns a string representation of the XOR expression.
     *
     * @return a string representation of the XOR expression.
     */
    @Override
    public String toString() {
        return "(" + getRight() + " ^ " + getLeft() + ")";
    }
}
