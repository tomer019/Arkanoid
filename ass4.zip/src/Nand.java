//Tomer Grady 319126991

/**
 * The Nand class represents a binary NAND (Not AND) expression.
 */
public class Nand extends BinaryExpression {

    /**
     * Constructor.
     *
     * @param first  the first operand.
     * @param second the second operand.
     */
    public Nand(Expression first, Expression second) {
        super(first, second);
    }

    /**
     * Applies the NAND operation on the operands.
     *
     * @param one the first operand.
     * @param two the second operand.
     * @return the result of the NAND operation.
     */
    @Override
    public boolean calculate(boolean one, boolean two) {
        return !(one && two);
    }

    /**
     * Returns a new expression where all operations are expressed using only NAND operations.
     *
     * @return the NANDified expression.
     */
    @Override
    public Expression nandify() {
        return new Nand(getRight().nandify(), getLeft().nandify());
    }

    /**
     * Returns a new expression where all operations are expressed using only NOR operations.
     *
     * @return the NORified expression.
     */
    @Override
    public Expression norify() {
        // Norify the first and second operand of the Xnor expression
        Expression one = super.getRight().norify();
        Expression two = super.getLeft().norify();

        // Create a NOR of the first and second operand with itself (equivalent to NOT)
        Expression three = new Nor(one, one);
        Expression four = new Nor(two, two);

        // Return the NOR equivalent of the Xnor operation using NOR expressions
        return new Nor(new Nor(three, four), new Nor(three, four));
    }


    /**
     * Returns a string representation of the expression.
     *
     * @return the string representation.
     */
    @Override
    public String toString() {
        return "(" + getRight() + " A " + getLeft() + ")";
    }


    /**
     * Simplifies the expression as much as possible.
     *
     * @return the simplified expression.
     */
    @Override
    public Expression simplify() {
        Expression result = super.simplify();
        if (result.equals(Val.TRUE) || result.equals(Val.FALSE)) {
            return result;
        }

        Expression first = getRight().simplify();
        Expression second = getLeft().simplify();

        // Applying simplification rules specific to NAND
        if ((first.equals(Val.FALSE)) || (second.equals(Val.FALSE))) {
            return Val.TRUE; // A NAND F or F NAND A = T
        }
        if (first.equals(Val.TRUE)) {
            return new Not(second).simplify(); // T NAND A = ~A
        }
        if (second.equals(Val.TRUE)) {
            return new Not(first).simplify(); // A NAND T = ~A
        }
        if (first.equals(second)) {
            return new Not(first).simplify(); // A NAND A = ~A
        }
        return new Nand(first, second);
    }

}
